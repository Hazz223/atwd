/**
 * Description of RefreshButton
 * Needed to refresh the page
 * 
 * @author hlp2-winser
 */

$(".refresh-button").click(function(){
    // when clicked, refresh the page.
    //http://stackoverflow.com/questions/19207781/jquery-refresh-reload-the-page-on-clicking-a-button
    location.reload(true);
    
});

